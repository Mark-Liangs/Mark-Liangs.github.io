# Recommended parameters for MOMA.
lamda=0.1
c_val=0.9
# Use the MOMA neighborhood search threshold when enabled.
use_moma=True
