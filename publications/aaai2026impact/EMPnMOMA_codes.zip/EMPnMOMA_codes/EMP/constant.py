import utils

mean_fp_1, std_fp_1 = 0.0204, 0.1466
mean_fp_2, std_fp_2 = 0.1023, 0.1296
var_fp_1, var_fp_2 = std_fp_1 ** 2, std_fp_2 ** 2

# p denotes the probability of being -1 and q denotes the probability of being 0 in the ternary distribution.
p_1, q_1 = 0.1310, 0.7903
p_2, q_2 = 0.1859, 0.7170
mean_tp_1, var_tp_1 = utils.cal_mean_var_tp(p_1, q_1)
mean_tp_2, var_tp_2 = utils.cal_mean_var_tp(p_2, q_2)

p_1_moma, q_1_moma = 0.0903, 0.8402
p_2_moma, q_2_moma = 0.0691, 0.8564
mean_tp_1_moma, var_tp_1_moma = utils.cal_mean_var_tp(p_1_moma, q_1_moma)
mean_tp_2_moma, var_tp_2_moma = utils.cal_mean_var_tp(p_2_moma, q_2_moma)
